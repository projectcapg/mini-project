package com.cg.QMapper;

public interface ApplicationQMapper {
	public static final String INSERT = "INSERT INTO Application VALUES(applicationId_seq.NEXTVAL,?,?,?,?,?,?,?,'APPLIED',NULL)";
	public static final String CURR_APP_ID = "SELECT applicationId_seq.CURRVAL FROM DUAL";
	public static final String SELECT_ALL_PS = "SELECT * FROM Programs_Scheduled";
	public static final String STATUS_usingID = "SELECT STATUS,date_of_interview FROM APPLICATION WHERE APPLICATION_ID=?";
	public static final String SCH_PROGRAM_ID = "select scheduled_program_id from programs_scheduled";
}
