package com.cg.test;

import java.io.IOException;

import org.junit.Test;

import com.cg.Exception.UASException;
import com.cg.service.AdminService;
import com.cg.service.AdminServiceImpl;

import junit.framework.Assert;

public class AdminTest {

	AdminService serve = null;

	public AdminTest() throws IOException {
		serve = new AdminServiceImpl();
	}

	@Test
	public void Test1() throws UASException {
		Assert.assertNotNull(serve.isValidEligibility("Btech"));
	}

	@Test
	public void Test2() throws UASException {
		Assert.assertNotNull(serve.getStatus("221"));
	}

	@Test
	public void Test3() throws UASException {

		Assert.assertNotNull(serve.isValidScheduledName("MATHS"));
	}

	@Test
	public void Test4() throws UASException {

		Assert.assertNotNull(serve.isValidScheduledName("dxfd"));

	}

	@Test
	public void Test5() throws UASException {

		Assert.assertNotNull(serve.getProgramsOffered());

	}

	@Test
	public void Test6() {
		Assert.assertEquals(true, serve.isValidDegree("Certification"));
	}

	@Test
	public void Test7() throws UASException {

		Assert.assertNotNull(serve.getProgramsOfferedDetails());
	}

	@Test
	public void Test8() throws UASException {
		Assert.assertNotNull(serve.isValidDuration(5644));
	}

}