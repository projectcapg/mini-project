package com.cg.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.cg.Exception.UASException;
import com.cg.QMapper.AdminQMapper;
import com.cg.dto.Application;
import com.cg.dto.ProgramOffered;
import com.cg.dto.ProgramScheduled;
import com.cg.util.DBUtil;
import com.cg.util.LoggerClass;
import com.cg.util.MyStringDateUtil;

public class AdminDAOImpl implements AdminDAO {

	Connection con = null;
	Logger logger = null;

	public AdminDAOImpl() throws IOException {
		super();
		con = DBUtil.getConnection();
		logger = LoggerClass.getLogger(this.getClass());
	}

	/*******************************************************************************************************
	 * - Function Name : addProgram() - Input Parameters : programOffered object -
	 * Return Type : void - Author : CAPGEMINI - Creation Date : 12/09/2019 -
	 * Description : adding program details to database
	 * 
	 * @throws UASException
	 ********************************************************************************************************/

	@Override
	public void addProgram(ProgramOffered obj) throws UASException {
		try {
			PreparedStatement pst = con.prepareStatement(AdminQMapper.INSERT_PO);
			pst.setString(1, obj.getProgramName());
			pst.setString(2, obj.getDescription());
			pst.setString(3, obj.getApplicantEligibility());
			pst.setInt(4, obj.getDuration());
			pst.setString(5, obj.getDegreeCertificateOffered());
			pst.execute();
			logger.info("New Program Added Successfully with program name:" + obj.getProgramName());
		} catch (SQLException e) {
			logger.error("Error occured in Adding program");
			throw new UASException("Error occured in adding program");
		}
	}

	/*******************************************************************************************************
	 * - Function Name : deleteProgram() - Input Parameters : String programName -
	 * Return Type : boolean - Author : CAPGEMINI - Creation Date : 12/09/2019 -
	 * Description : deletes the program from programScheduled
	 * 
	 * @throws UASException
	 ********************************************************************************************************/

	@Override
	public boolean deleteProgram(String programName) throws UASException {
		try {
			PreparedStatement pst = con.prepareStatement(AdminQMapper.DELETE_PS);
			pst.setString(1, programName);
			pst.execute();
			logger.info("Program Deleted Successfully named : " + programName);
			return true;
		} catch (SQLException e) {
			logger.error("Error occured in deleting program");
			throw new UASException("Program already has applicants.");
		}
	}

	/*******************************************************************************************************
	 * - Function Name : scheduleProgram() - Input Parameters : programScheduled
	 * object - Return Type : boolean - Author : CAPGEMINI - Creation Date :
	 * 12/09/2019 - Description : schedules the program
	 * 
	 * @throws UASException
	 ********************************************************************************************************/

	@Override
	public void scheduleProgram(ProgramScheduled obj) throws UASException {
		try {
			PreparedStatement pst = con.prepareStatement(AdminQMapper.INSERT_PS);
			pst.setString(1, obj.getScheduledProgramId());
			pst.setString(2, obj.getProgramName());
			pst.setString(3, obj.getLocation());
			pst.setDate(4, obj.getStartDate());
			pst.setDate(5, obj.getEndDate());
			pst.setInt(6, obj.getSessionsPerWeek());
			pst.execute();
			logger.info("Program Scheduled Successfully having id : " + obj.getScheduledProgramId());
		} catch (SQLException e) {
			logger.error("Error in scheduling Program");
			throw new UASException("Program does not get Scheduled");
		}
	}

	/*******************************************************************************************************
	 * - Function Name : getScheduledProgram() - Input Parameters : startDate and
	 * endDate - Return Type : ArrayList<ProgramScheduled> - Author : CAPGEMINI -
	 * Creation Date : 12/09/2019 - Description : returns all the scheduled programs
	 * whose startDate < date < endDate
	 * 
	 * @throws UASException
	 ********************************************************************************************************/

	@Override
	public ArrayList<ProgramScheduled> getScheduledProgram(Date startDate, Date endDate) throws UASException {
		ArrayList<ProgramScheduled> list = new ArrayList<ProgramScheduled>();
		try {
			PreparedStatement pst = con.prepareStatement(AdminQMapper.GET_SCH_PROGRAM);
			pst.setDate(1, startDate);
			pst.setDate(2, endDate);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				list.add(new ProgramScheduled(rs.getString(1), rs.getString(2), rs.getString(3), rs.getDate(4),
						rs.getDate(5), rs.getInt(6)));
			}
			logger.info("Scheduled Programs are fetched Successfully with Start date " + startDate + " and end date "
					+ endDate);
		} catch (SQLException e) {
			throw new UASException("Error in fetching Programs.");
		}
		return list;
	}

	/*******************************************************************************************************
	 * 
	 * - Function Name : getStatus() - Input Parameters : status - Return Type :
	 * ArrayList<Application> - Author : CAPGEMINI - Creation Date : 12/09/2019 -
	 * Description : Returns all the application based on status
	 * 
	 * @throws UASException
	 ********************************************************************************************************/

	@Override
	public ArrayList<Application> getStatus(String status) throws UASException {
		ArrayList<Application> list = new ArrayList<Application>();
		try {
			System.out.println(status);
			PreparedStatement pst = con.prepareStatement(AdminQMapper.APPLICANT_BY_STATUS);
			pst.setString(1, status);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				if (rs.getDate(10) == null) {
					Application ps = new Application(rs.getInt(1), rs.getString(2),
							MyStringDateUtil.fromSqlToLocalDate(rs.getDate(3)), rs.getString(4), rs.getInt(5),
							rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9));
					list.add(ps);
				} else {
					Application ps = new Application(rs.getInt(1), rs.getString(2), rs.getDate(3), rs.getString(4),
							rs.getInt(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9),
							rs.getDate(10));
					list.add(ps);
				}
			}
			logger.info("Applicants are fetched with status " + status);
		} catch (SQLException e) {
			logger.error("Error in fetching applicants with status : " + status);
			throw new UASException("No Aplication could be found");
		}
		return list;
	}

	/*******************************************************************************************************
	 * 
	 * - Function Name : getProgramsOffered() - Input Parameters : nil - Return Type
	 * : ArrayList<String> - Author : CAPGEMINI - Creation Date : 12/09/2019 -
	 * Description : Returns the programs offered name
	 * 
	 * @throws UASException
	 ********************************************************************************************************/

	@Override
	public ArrayList<String> getProgramsOffered() throws UASException {
		ArrayList<String> list = new ArrayList<String>();
		try {
			PreparedStatement pst = con.prepareStatement(AdminQMapper.PROGRAMNAME_fromPO);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				list.add(rs.getString(1));
			}
		} catch (SQLException e) {
			throw new UASException("No Programs Found");
		}
		return list;
	}

	/*******************************************************************************************************
	 * 
	 * - Function Name : getProgramsOfferedDetails() - Input Parameters : nil -
	 * Return Type : ArrayList<ProgramOffered> - Author : CAPGEMINI - Creation Date
	 * : 12/09/2019 - Description : Returns all the programs offered
	 * 
	 * @throws UASException
	 ********************************************************************************************************/

	@Override
	public ArrayList<ProgramOffered> getProgramsOfferedDetails() throws UASException {
		ArrayList<ProgramOffered> list = new ArrayList<ProgramOffered>();
		try {
			PreparedStatement pst = con.prepareStatement(AdminQMapper.GET_PROG_OFFERED);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				list.add(new ProgramOffered(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4),
						rs.getString(5)));
			}
			logger.info("All offered programs are fetched");
		} catch (SQLException e) {
			logger.error("Error in fetching Offered Programs ");
			throw new UASException(e.getMessage());
		}
		return list;
	}
}