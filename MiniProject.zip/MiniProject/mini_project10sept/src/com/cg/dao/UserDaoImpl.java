package com.cg.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.Exception.UASException;
import com.cg.QMapper.UsersQMapper;
import com.cg.util.DBUtil;

public class UserDaoImpl implements UserDao{
	
	public UserDaoImpl(){		
	}

	@Override
	public String ReturnRole(String loginId, String password) throws UASException {
		Connection con=null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;	
		try
		{
			con=DBUtil.getConnection();
			pstmt = con.prepareStatement(UsersQMapper.SELECT_PWD_usingID);
			pstmt.setString(1, loginId);
			rs=pstmt.executeQuery();
			rs.next();
			String checkPass=rs.getString(1);
			if(checkPass.equals(password))
			{
				pstmt = con.prepareStatement(UsersQMapper.SELECT_ROLE_usingID);
				pstmt.setString(1, loginId);
				rs=pstmt.executeQuery();
				rs.next();
				return rs.getString(1);				
			}			
			else
			{
				return "Invalid Password";
			}
		}
		catch(SQLException | IOException e)
		{
			throw new UASException("Invalid Login Credentials!");
		}
	}
}