package com.cg.service;

import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.Exception.UASException;
import com.cg.dao.AdminDAO;
import com.cg.dao.AdminDAOImpl;
import com.cg.dao.ApplicationDAO;
import com.cg.dao.ApplicationDAOImpl;
import com.cg.dto.Application;
import com.cg.dto.ProgramOffered;
import com.cg.dto.ProgramScheduled;

public class AdminServiceImpl implements AdminService {

	AdminDAO adao = null;

	public AdminServiceImpl() throws IOException {
		super();
		adao = new AdminDAOImpl();
	}

	

	@Override
	public void addProgram(ProgramOffered obj) throws UASException {
		adao.addProgram(obj);
	}

	@Override
	public boolean deleteProgram(String programName) throws UASException {

		return adao.deleteProgram(programName);

	}

	@Override
	public void scheduleProgram(ProgramScheduled obj) throws UASException {
		adao.scheduleProgram(obj);
	}

	@Override
	public ArrayList<ProgramScheduled> getScheduledProgram(Date startDate, Date endDate) throws UASException {
		return adao.getScheduledProgram(startDate, endDate);
	}

	@Override
	public ArrayList<Application> getStatus(String status) throws UASException {
		return adao.getStatus(status);
	}

	@Override
	public ArrayList<String> getProgramsOffered() throws UASException {
		return adao.getProgramsOffered();
	}

	@Override
	public ArrayList<ProgramOffered> getProgramsOfferedDetails() throws UASException {
		return adao.getProgramsOfferedDetails();
	}

	public boolean isValidName(String progName) throws UASException {
		Pattern namePattern = Pattern.compile("[A-Za-z0-9]{3,5}");
		Matcher nameMatcher = namePattern.matcher(progName);
		boolean isValid = nameMatcher.matches();

		return isValid;
	}

	public boolean isValidScheduledName(String progName) throws UASException {
		Pattern namePattern = Pattern.compile("[A-Za-z0-9]{3,5}");
		Matcher nameMatcher = namePattern.matcher(progName);
		boolean isValid = nameMatcher.matches();

		if (isValid) {
			ApplicationDAO apdao = new ApplicationDAOImpl();
			ArrayList<ProgramScheduled> ps = apdao.getAllScheduledPrograms();

			Iterator<ProgramScheduled> itr = ps.iterator();
			while (itr.hasNext()) {
				if (itr.next().getScheduledProgramId().equals(progName))
					return true;
			}
		}

		return false;
	}

	public boolean isValidDescription(String desc) throws UASException {
		Pattern descPattern = Pattern.compile("[A-Za-z0-9\\s]{5,20}");
		Matcher descMatcher = descPattern.matcher(desc);

		boolean isValid = descMatcher.matches();
		
		return isValid;
	}

	public boolean isValidEligibility(String eligibility) throws UASException {
		Pattern eligibilityPattern = Pattern.compile("[A-Za-z0-9\\s]{10,40}");
		Matcher eligibilityMatcher = eligibilityPattern.matcher(eligibility);

		boolean isValid = eligibilityMatcher.matches();
		
		return isValid;
	}

	public boolean isValidDuration(int duration) throws UASException {
		String period = Integer.toString(duration);
		Pattern durationPattern = Pattern.compile("[1-9]{1,}");
		Matcher durationMatcher = durationPattern.matcher(period);

		boolean isValid = durationMatcher.matches();
		
		return isValid;
	}

	public boolean isValidDegree(String degree) {
		Pattern degreePattern = Pattern.compile("[A-Za-z ]{3,20}");
		Matcher degreeMatcher = degreePattern.matcher(degree);

		boolean isValid = degreeMatcher.matches();
		return isValid;
	}

	@Override
	public boolean isValidLocation(String location) throws UASException {
		Pattern degreePattern = Pattern.compile("[A-Za-z0-9\\s]{3,10}");
		Matcher degreeMatcher = degreePattern.matcher(location);

		boolean isValid = degreeMatcher.matches();
		return isValid;
	}

	public boolean isValidDate(ProgramScheduled program) {
		return (isValidDoi(program.getStartDate(), program.getEndDate()));
	}

	public boolean isValidDoiScheduleDetails(Date start, Date end) {

		Date today = Date.valueOf(LocalDate.now());
		boolean isValid = false;
		if(today.compareTo(start) <= 0) {
			if (start.after(end)) {
				System.out.println("Start Date is after End Date");
				isValid = false;
			} else if (start.before(end)) {
				isValid = true;
			} else if (start.equals(end)) {
				System.out.println("Start Date is same as End Date");
				isValid = false;
			}
		}
		else
			return false;
		return isValid;
	}
	
	public boolean isValidDoi(Date start, Date end) {

		
		boolean isValid = false;
		
			if (start.after(end)) {
				System.out.println("Start Date is after End Date");
				isValid = false;
			} else if (start.before(end)) {
				isValid = true;
			} else if (start.equals(end)) {
				System.out.println("Start Date is same as End Date");
				isValid = false;
			}
		
			
		return isValid;
	}



	

}
