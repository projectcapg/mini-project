package com.cg.service;

import java.sql.Date;
import java.util.ArrayList;

import com.cg.Exception.UASException;
import com.cg.dto.Application;
import com.cg.dto.ProgramOffered;
import com.cg.dto.ProgramScheduled;

public interface AdminService {

	
	void addProgram(ProgramOffered obj) throws UASException ;

	boolean deleteProgram(String programName) throws UASException ;

	void scheduleProgram(ProgramScheduled obj) throws UASException;

	ArrayList<ProgramScheduled> getScheduledProgram(Date startDate, Date endDate) throws UASException;
	
	public boolean isValidScheduledName(String progName) throws UASException ;

	ArrayList<Application> getStatus(String status) throws UASException;

	ArrayList<String> getProgramsOffered() throws UASException;

	ArrayList<ProgramOffered> getProgramsOfferedDetails() throws UASException;
	
	public boolean isValidName(String progName) throws UASException;
	
	public boolean isValidDescription(String desc) throws UASException;
	
	public boolean isValidEligibility(String eligibility) throws UASException;
	
	public boolean isValidDuration(int duration) throws UASException;
	
	public boolean isValidDegree(String degree) ;
	
	public boolean isValidLocation(String location) throws UASException;
	
	public boolean isValidDate(ProgramScheduled program);

	public boolean isValidDoiScheduleDetails(Date start, Date end);
	
	
}
