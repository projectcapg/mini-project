package com.cg.util;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;


public class DBUtil {

	static String unm;
	static String pwd;
	static String url;
	static String driver;
	
	public static Connection getConnection() throws IOException
	{
		Connection con = null;
		
		Properties dbProps = getDBInfo();
		unm = dbProps.getProperty("dbUserName");
		pwd = dbProps.getProperty("dbPassword");
		url = dbProps.getProperty("dbUrl");
		driver = dbProps.getProperty("dbDriver");
		
		try 
		{

			con = DriverManager.getConnection(url, unm, pwd);

		}
		catch (SQLException e) 
		{

			e.printStackTrace();
		}
			
		
		return con;
	}
	
	public static Properties getDBInfo() throws IOException
	{
		FileReader fr = new FileReader("dbInfo.properties");
		
		Properties myProps = new Properties();
		myProps.load(fr);
		return myProps;
		
	}
}





